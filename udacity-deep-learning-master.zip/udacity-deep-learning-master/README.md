# udacity-deep-learning
Assignment solutions for https://www.udacity.com/course/deep-learning--ud730

# Steps
install docker
https://docs.docker.com/engine/installation/

git clone git@github.com:sdurgi17/udacity-deep-learning.git

Run the docker container from google cloud repository.
docker run -it -p 8888:8888  -v path_to(udacity-deep-learning):/notebooks b.gcr.io/tensorflow-udacity/assignments:0.5.0



